#pragma once
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/common.hpp>
#include <iomanip>
#include "world.hpp"
class renderer
{
private:
	static void error_callback(int error, const char* description)
	{
		fprintf(stderr, "Error: %s\n", description);
	}
	GLFWwindow* m_window = nullptr;

	glm::mat4 view;
	glm::mat4 projection;
public:
	inline bool shouldClose()
	{
		return glfwWindowShouldClose(m_window);
	}
	renderer(std::string title)
	{
		std::cout << std::fixed;
		std::cout << std::setprecision(6);
		std::cout << 0.000000 << " : " << "Initializing GLFW..." << std::endl;
		if (!glfwInit())
		{
			throw std::exception("Failed to init GLFW!");
			exit(-1);
		}
		std::cout << (float)glfwGetTime() << " : " << "Success" << std::endl;
		glfwWindowHint(GLFW_SAMPLES, 4);
		glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
		glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 5);
		glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
		auto monitor = glfwGetPrimaryMonitor();
		auto mode = glfwGetVideoMode(monitor);
		std::cout << (float)glfwGetTime() << " : " << "Creating Window..." << std::endl;
		m_window = glfwCreateWindow(mode->width, mode->height, title.c_str(), monitor, nullptr);
		if (!m_window)
		{
			throw std::exception("Failed to create Window!");
			exit(-1);
		}
		std::cout << (float)glfwGetTime() << " : " << "Success" << std::endl;
		glfwMakeContextCurrent(m_window);
		std::cout << (float)glfwGetTime() << " : " << "Initializing GLEW..." << std::endl;
		glewExperimental = true;
		if (glewInit() != GLEW_OK) 
		{
			throw std::exception("Failed to init GLEW!");
			exit(-1);
		}
		std::cout << (float)glfwGetTime() << " : " << "Success" << std::endl;
	}
	void clear()
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}
	void render(world &toRender)
	{
		
	}
	void update()
	{
		glfwPollEvents();
		glfwSwapBuffers(m_window);
	}
	~renderer()
	{
		glfwDestroyWindow(m_window);
		glfwTerminate();
	}
};
