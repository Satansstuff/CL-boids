#pragma once
#include <memory>
#include <random>
#include <time.h>
#include <vector>
#include <fstream>
#include <streambuf>
#include <GLFW/glfw3.h>
#include <CL/cl.hpp>
//https://github.com/9prady9/CLGLInterop/blob/master/examples/partsim.cpp
const size_t numClusters = 5;
const size_t numBoidsPerCluser = 10;

constexpr auto MAX_SOURCE_SIZE = (0x100000);
struct boid
{
	glm::vec2 pos, vel, acceleration;
	size_t flockID;
	boid(glm::vec2 pos, size_t flockID)
	{
		this->pos = pos;
		this->flockID = flockID;
	}
};
class world
{
private:
	std::unordered_map<std::string, std::string> cl_code;
	std::vector<std::vector<std::shared_ptr<boid>>> clusters;
	cl_context context;
	cl_command_queue command_queue;
	cl_platform_id platform_id = NULL;
	cl_device_id device_id = NULL;
	glm::vec2 separation()
	{
		glm::vec2 ret;
		
	}
public:
	world()
	{
		srand((unsigned)std::time(NULL));
		{
			std::ifstream t("separation.cl");
			std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
			cl_code["separation"] = str;
		}
		std::cout << (float)glfwGetTime() << " : Loading OpenCL context" << std::endl;
		cl_uint ret_num_devices;
		cl_uint ret_num_platforms;
		cl_int ret = clGetPlatformIDs(1, &platform_id, &ret_num_platforms);
		if (ret != CL_SUCCESS)
		{
			std::cout << (float)glfwGetTime() << " : Failed to get platforms" << std::endl;
			return;
		}
		ret = clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_DEFAULT, 1, &device_id, &ret_num_devices);
		if (ret != CL_SUCCESS) 
		{
			std::cout << (float)glfwGetTime() << " : Failed to load context" << std::endl;
			return;
		}
		context = clCreateContext(NULL, 1, &device_id, NULL, NULL, &ret);
		command_queue = clCreateCommandQueue(context, device_id, 0, &ret);
		char buf[4096];
		ret = clGetPlatformInfo(platform_id, CL_PLATFORM_NAME, sizeof(buf), buf, NULL);
		if (ret != CL_SUCCESS)
		{
			std::cout << (float)glfwGetTime() << " : Failed to get device name" << std::endl;
			return;
		}
		ret = clGetDeviceInfo(device_id, CL_DEVICE_NAME, sizeof(buf), buf, NULL);
		std::cout << (float)glfwGetTime() << " : Success" << std::endl;
		std::cout << (float)glfwGetTime() << " : Using device: " << buf << std::endl;
	}
	void update(double dt)
	{

	}
};