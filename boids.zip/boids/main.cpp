#include <iostream>
#pragma comment(lib, "glfw3.lib")
#pragma comment(lib, "glew32.lib")
#pragma comment(lib, "OpenCL.lib")
#pragma comment(lib, "opengl32.lib")
#include "renderer.hpp"
#include "world.hpp"
int main(int argc, char *argv[])
{
	renderer m_renderer("Boids");
	world m_world;
	while (!m_renderer.shouldClose())
	{
		m_renderer.clear();
		m_renderer.update();
	}
	std::cin.ignore();
	return EXIT_SUCCESS;
}